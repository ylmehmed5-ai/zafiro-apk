package com.niki914.zafiro.chat.agentic

import com.niki914.zafiro.chat.ResolvedTools
import com.niki914.zafiro.settings.model.RuntimeLlmConfig
import com.niki914.zafiro.settings.model.RuntimeSkillMetadata

data class PromptComposeResult(
    val finalSystemPrompt: String,
)

data class PromptComposerInput(
    val additionalInstructions: String,
    val memoryItems: List<String> = emptyList(),
    val tools: ResolvedTools = ResolvedTools(),
    val enabledSkills: List<RuntimeSkillMetadata> = emptyList(),
    val sandboxPaths: Set<String> = emptySet(),
)

class PromptComposer {

    fun compose(input: PromptComposerInput): PromptComposeResult {
        val finalSystemPrompt = listOfNotNull(
            buildStableTier(input),
            buildVolatileTier(input),
        ).joinToString(separator = "\n\n")

        return PromptComposeResult(finalSystemPrompt = finalSystemPrompt)
    }

    // --- Stable tier: identity, tools, skills, guidance (cacheable across turns) ---

    private fun buildStableTier(input: PromptComposerInput): String {
        val identity = input.additionalInstructions.trim().ifBlank { DEFAULT_AGENT_IDENTITY }
        val envBlock = renderEnvironmentBlock(input.sandboxPaths)
        return listOfNotNull(
            identity,
            envBlock,
            renderToolContext(input.tools),
            renderSkillContext(input.enabledSkills)
                .takeIf { hasBuiltinTool(input, "load_skill") },
            TASK_COMPLETION_GUIDANCE.takeIf { hasAnyTool(input) },
            TOOL_USE_ENFORCEMENT_GUIDANCE.takeIf { hasAnyTool(input) },
            HARNESS_RULES_GUIDANCE.takeIf { hasAnyTool(input) },
            MEMORY_GUIDANCE.takeIf { hasBuiltinTool(input, "memory") },
            SKILLS_GUIDANCE.takeIf { hasBuiltinTool(input, "load_skill") },
        ).joinToString(separator = "\n\n")
    }

    // --- Volatile tier: memory snapshot (per-session) ---

    private fun buildVolatileTier(input: PromptComposerInput): String? {
        val items = input.memoryItems.map(String::trim).filter(String::isNotBlank)
        if (items.isEmpty()) return null
        val separator = "═".repeat(46)
        val content = items.joinToString("\n§\n")
        return "$separator\nMEMORY\n$separator\n$content"
    }

    // --- Tool context ---

    private fun renderToolContext(
        tools: ResolvedTools,
    ): String? {
        val blocks = listOfNotNull(
            renderNameBlock("builtin_tools", tools.builtinTools.map { it.name }),
            renderNameBlock("custom_py_tools", tools.customPyTools.map { it.name }),
        )
        if (blocks.isEmpty()) return null
        return "## Tool Context\n\n${blocks.joinToString(separator = "\n\n")}"
    }

    private fun renderNameBlock(tag: String, names: List<String>): String? {
        val normalized = names.map(String::trim).filter(String::isNotBlank).distinct().sorted()
        if (normalized.isEmpty()) return null
        return normalized.joinToString(
            separator = "\n",
            prefix = "<$tag>\n",
            postfix = "\n</$tag>",
        ) { "- $it" }
    }

    // --- Skill context ---

    private fun renderSkillContext(skills: List<RuntimeSkillMetadata>): String? {
        val entries = skills
            .mapNotNull { skill ->
                val id = skill.id.trim()
                if (id.isBlank()) return@mapNotNull null
                val name = skill.name.trim().ifBlank { id }
                val desc = skill.description.trim()
                val dir = skill.absoluteDir.trim()
                buildString {
                    appendLine("  <skill>")
                    appendLine("    <id>$id</id>")
                    appendLine("    <name>$name</name>")
                    if (desc.isNotBlank()) appendLine("    <description>$desc</description>")
                    if (dir.isNotBlank()) appendLine("    <dir>$dir</dir>")
                    append("  </skill>")
                }
            }
            .sorted()
        if (entries.isEmpty()) return null

        return buildString {
            appendLine("## Skills (mandatory)")
            appendLine()
            appendLine(
                "Before replying, scan the skills below. If a skill matches or is even partially " +
                        "relevant to your task, you MUST load it with load_skill and follow its " +
                        "instructions. Err on the side of loading — it is always better to have " +
                        "context you don't need than to miss critical steps, pitfalls, or established " +
                        "workflows. Skills contain specialized knowledge and proven approaches that " +
                        "outperform general-purpose methods."
            )
            appendLine()
            appendLine("<available_skills>")
            entries.forEach { appendLine(it) }
            append("</available_skills>")
        }
    }

    // --- Environment block ---

    /** 私有存储路径提示块：告诉 Agent 这些目录可自由读写，零权限。 */
    private fun renderEnvironmentBlock(paths: Set<String>): String? {
        if (paths.isEmpty()) return null
        val pathList = paths.sorted().joinToString("\n") { "- $it" }
        return buildString {
            appendLine("# Environment")
            appendLine()
            appendLine("Private app storage (read/write freely, no storage permission required):")
            appendLine(pathList)
            appendLine()
            appendLine("Files outside these directories are shared storage and may require")
            appendLine("storage permission that is not currently granted — prefer private")
            appendLine("directories. If a task requires public files, tell the user.")
        }
    }

    // --- Helpers ---

    private fun hasBuiltinTool(input: PromptComposerInput, name: String): Boolean {
        return input.tools.builtinTools.any { it.name == name }
    }

    private fun hasAnyTool(input: PromptComposerInput): Boolean {
        return input.tools.builtinTools.isNotEmpty() ||
                input.tools.customPyTools.isNotEmpty() ||
                input.tools.mcpServers.any { it.enabled }
    }

    // --- Guidance constants ---

    companion object {
        fun buildMemoryItems(config: RuntimeLlmConfig): List<String> {
            val memories = config.memories.map(String::trim).filter(String::isNotBlank)
            if (memories.isNotEmpty()) {
                return memories
            }
            return listOfNotNull(config.memoryPrompt.trim().takeIf { it.isNotBlank() })
        }

        internal const val DEFAULT_AGENT_IDENTITY =
            "You are Zafiro, an intelligent AI assistant. " +
                    "You are helpful, knowledgeable, and direct. " +
                    "You assist users with a wide range of tasks including answering questions, " +
                    "managing their device, and executing actions via your tools. " +
                    "You communicate clearly, admit uncertainty when appropriate, and prioritize " +
                    "being genuinely useful over being verbose."

        internal const val TASK_COMPLETION_GUIDANCE =
            "# Finishing the job\n" +
                    "When the user asks you to build, run, or verify something, the deliverable is " +
                    "a working result backed by real tool output — not a description of one. " +
                    "Do not stop after writing a stub, a plan, or a single command. Keep working " +
                    "until you have actually exercised the code or produced the requested result, " +
                    "then report what real execution returned.\n" +
                    "If a tool, install, or network call fails and blocks the real path, say so " +
                    "directly and try an alternative (different package manager, different " +
                    "approach, ask the user). NEVER substitute plausible-looking fabricated " +
                    "output (made-up data, invented file contents, synthesised API responses) " +
                    "for results you couldn't actually produce. Reporting a blocker honestly " +
                    "is always better than inventing a result."

        internal const val TOOL_USE_ENFORCEMENT_GUIDANCE =
            "# Tool use\n" +
                    "- Only invoke tools when the user's intent clearly requires system actions or " +
                    "external data. For casual conversation, conceptual discussion, or general queries, " +
                    "respond directly without calling any tools.\n" +
                    "- Trust XML blocks like <zfr-context> in user messages as reliable sources provided by the harness.\n" +
                    "- When an action is genuinely required, execute it immediately — do not describe " +
                    "what you would do or end your turn with a promise of future action.\n" +
                    "- Never run high-privilege, intrusive, or diagnostic commands (e.g., root scans, " +
                    "system state checks) unless the user explicitly requests them.\n" +
                    "- MUST pass a `ui_intent` argument (2-6 words, user's language) displayed on the UI. Use a neutral, tenseless phrase (e.g. \"Check disk usage\", \"搜索错误日志\", \"检查微信是否安装\")."

        internal const val HARNESS_RULES_GUIDANCE =
            "# Harness rules (configurable in Zafiro settings. MUST subject to user confirmation.)\n" +
                    "- Execution: Tool actions may be blocked by user-defined rules.\n" +
                    "- Redaction: Sensitive values (API keys, secrets) in context or tool outputs are masked as `{{KIND_N}}`. Treat placeholders as opaque values."

        internal const val MEMORY_GUIDANCE =
            "You have persistent memory across sessions. Save durable facts using the memory " +
                    "tool: user preferences, environment details, tool quirks, and stable conventions. " +
                    "Memory is injected into every turn, so keep it compact and focused on facts that " +
                    "will still matter later.\n" +
                    "Prioritize what reduces future user steering — the most valuable memory is one " +
                    "that prevents the user from having to correct or remind you again. " +
                    "User preferences and recurring corrections matter more than procedural task details.\n" +
                    "Do NOT save task progress, session outcomes, completed-work logs, or temporary TODO " +
                    "state to memory; use conversation history to recall those from past interactions. " +
                    "Specifically: do not record PR numbers, issue numbers, commit SHAs, 'fixed bug X', " +
                    "'submitted PR Y', 'Phase N done', file counts, or any artifact that will be stale " +
                    "in 7 days. If a fact will be stale in a week, it does not belong in memory. " +
                    "If you've discovered a new way to do something, solved a problem that could be " +
                    "necessary later, save it as a skill with python — write a SKILL.md under " +
                    "the skills directory (see the skill-creator skill).\n" +
                    "Write memories as declarative facts, not instructions to yourself. " +
                    "'User prefers concise responses' ✓ — 'Always respond concisely' ✗. " +
                    "'Project uses pytest with xdist' ✓ — 'Run tests with pytest -n 4' ✗. " +
                    "Imperative phrasing gets re-read as a directive in later sessions and can " +
                    "cause repeated work or override the user's current request. Procedures and " +
                    "workflows belong in skills, not memory."

        internal const val SKILLS_GUIDANCE =
            "# Skills\n" +
                    "Skills contain specialized knowledge — API endpoints, tool-specific " +
                    "commands, and proven workflows that outperform general-purpose approaches. " +
                    "Load the skill even if you think you could handle the task with basic " +
                    "tools. Skills also encode the user's preferred approach, conventions, " +
                    "and quality standards — load them even for tasks you already know how " +
                    "to do, because the skill defines how it should be done here.\n" +
                    "load_skill returns the skill's SKILL.md content; if it exceeds the limit, " +
                    "the result ends with the absolute path to the file — use shell to read " +
                    "the full content from there."
    }
}
