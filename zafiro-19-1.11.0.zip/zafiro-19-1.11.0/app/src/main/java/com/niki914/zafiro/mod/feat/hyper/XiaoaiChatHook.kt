package com.niki914.zafiro.mod.feat.hyper

import com.niki914.logging.Logger
import com.niki914.zafiro.chat.ActiveTurnStore
import com.niki914.zafiro.mod.feat.AbstractAssistantHook
import com.niki914.zafiro.mod.feat.hyper.subhooks.BlockNativeInstructionByWhitelistHook
import com.niki914.zafiro.mod.feat.hyper.subhooks.BlockNativeTtsPlaybackHook
import com.niki914.zafiro.mod.feat.hyper.subhooks.CaptureInputHook
import com.niki914.zafiro.mod.feat.hyper.subhooks.CaptureResponseTargetHook
import com.niki914.zafiro.mod.feat.hyper.subhooks.RenderTextStreamCardHook
import com.niki914.zafiro.runtime.client.AssistantFrame
import com.niki914.zafiro.runtime.client.AssistantTextSource
import de.robv.android.xposed.callbacks.XC_LoadPackage
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope

class XiaoaiChatHook(
    scope: CoroutineScope,
    textSource: AssistantTextSource,
) : AbstractAssistantHook(scope, textSource) {
    override val name: String = "XiaoaiChatHook"

    private companion object {
        const val LOG_TAG = "niki914_zafiro_XiaoaiChatHook"
    }

    private var renderTextStreamCardHook: RenderTextStreamCardHook? = null

    @Volatile
    private var capturedResponseTarget: Any? = null
    private var targetReady = CompletableDeferred<Unit>()

    override suspend fun onSessionReset() {
        super.onSessionReset()
        targetReady.cancel()
        targetReady = CompletableDeferred()
        capturedResponseTarget = null
        renderTextStreamCardHook?.reset()
    }

    override fun installSessionHooks(lpparam: XC_LoadPackage.LoadPackageParam) {
        installFloatScreenDetachHooks(
            lpparam = lpparam,
            detachTarget = XiaoaiConfigProvider.FloatScreenDetach.detachTarget,
            resumeTarget = XiaoaiConfigProvider.FloatScreenDetach.resumeTarget
        )
    }

    override fun installResponseHooks(lpparam: XC_LoadPackage.LoadPackageParam) {
        CaptureResponseTargetHook(
            onCaptured = { target ->
                capturedResponseTarget = target
                targetReady.complete(Unit)
            }
        ).onHook(lpparam)

        BlockNativeInstructionByWhitelistHook().onHook(lpparam)

        BlockNativeTtsPlaybackHook().onHook(lpparam)

        renderTextStreamCardHook = RenderTextStreamCardHook()
            .also { it.onHook(lpparam) }
    }

    override fun installInputHooks(
        lpparam: XC_LoadPackage.LoadPackageParam,
        onInput: (roomId: String, query: String) -> Unit
    ) {
        CaptureInputHook(onInput = onInput).onHook(lpparam)
    }

    // 覆盖基类：渲染前需等待宿主 UI 卡片就绪（TODO 死等风险：若 Hook 永不触发则挂死）
    override suspend fun dispatchQueryToLLM(turnId: Long, roomId: String, query: String) {
        val startedAtMs = System.currentTimeMillis()
        var firstFrameLogged = false
        targetReady.cancel()
        targetReady = CompletableDeferred()
        Logger.i(
            LOG_TAG,
            "dispatch start turnId=$turnId roomId=$roomId queryLength=${query.length}"
        )

        try {
            textSource.submit(query).collect { frame ->
                if (!firstFrameLogged) {
                    firstFrameLogged = true
                    Logger.i(
                        LOG_TAG,
                        "dispatch first frame turnId=$turnId " +
                                "elapsedMs=${System.currentTimeMillis() - startedAtMs}"
                    )
                }
                if (frame.isFinal) {
                    val len = when (frame) {
                        is AssistantFrame.Update -> frame.content.length
                        is AssistantFrame.Error -> frame.message.length
                    }
                    Logger.i(
                        LOG_TAG,
                        "dispatch final frame turnId=$turnId " +
                                "elapsedMs=${System.currentTimeMillis() - startedAtMs} " +
                                "textLength=$len"
                    )
                }
                targetReady.await()
                renderStreamCard(turnId, roomId, frame)
            }
            Logger.i(
                LOG_TAG,
                "dispatch completed turnId=$turnId " +
                        "elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
        } catch (e: Exception) {
            Logger.e(
                LOG_TAG,
                "dispatch failed turnId=$turnId errorType=${e::class.simpleName} " +
                        "message=${e.message} elapsedMs=${System.currentTimeMillis() - startedAtMs}"
            )
            targetReady.await()
            renderStreamCard(
                turnId, roomId,
                AssistantFrame.Error(e.message ?: "Service unavailable"),
            )
        }
    }

    override suspend fun renderStreamCard(
        turnId: Long,
        roomId: String,
        chunk: String,
        isFirst: Boolean,
        isFinal: Boolean
    ) {
        if (!ActiveTurnStore.isActiveInjection(turnId)) {
            Logger.d(LOG_TAG, "render skipped inactive turnId=$turnId")
            return
        }

        renderTextStreamCardHook?.render(
            turnId = turnId,
            dialogId = roomId,
            target = capturedResponseTarget,
            chunk = chunk,
            isFirst = isFirst,
            isFinal = isFinal
        )
    }
}
