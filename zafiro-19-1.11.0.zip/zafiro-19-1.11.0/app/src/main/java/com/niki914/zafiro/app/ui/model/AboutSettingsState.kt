package com.niki914.zafiro.app.ui.model

import android.net.Uri
import androidx.annotation.StringRes
import com.niki914.uikit.base.ComposeMVIViewModel
import com.niki914.zafiro.app.R
import com.niki914.zafiro.repo.XRepo

enum class AboutSettingsItemId {
    AuthorHomepage,
    Github,
    Afdian,
    Telegram,
    FeatureFeedback,
    BugFeedback,
}

data class AboutSettingsItemUiState(
    val id: AboutSettingsItemId,
    @StringRes val titleRes: Int,
    val uri: String?,
    @StringRes val bodyTemplateRes: Int? = null,
    val feedbackTitle: String? = null,
) {
    val canOpen: Boolean
        get() = uri != null || bodyTemplateRes != null
}

data class AboutSettingsUiState(
    val items: List<AboutSettingsItemUiState> = emptyList(),
    val telemetryEnabled: Boolean = true,
    val showPrivacyDialog: Boolean = false,
)

sealed interface AboutSettingsIntent {
    data object Load : AboutSettingsIntent
    data class OpenItem(val id: AboutSettingsItemId) : AboutSettingsIntent
    data class ToggleTelemetry(val enabled: Boolean) : AboutSettingsIntent
    data object ShowPrivacyDialog : AboutSettingsIntent
    data object DismissPrivacyDialog : AboutSettingsIntent
    data object OpenTelemetryDoc : AboutSettingsIntent
}

sealed interface AboutSettingsEffect {
    data class OpenUri(val uri: String) : AboutSettingsEffect
    data class OpenFeedbackIssue(
        val title: String,
        @StringRes val bodyTemplateRes: Int,
        val languageTag: String,
    ) : AboutSettingsEffect
}

class AboutSettingsViewModel :
    ComposeMVIViewModel<AboutSettingsIntent, AboutSettingsUiState, AboutSettingsEffect>() {

    override fun initUiState(): AboutSettingsUiState {
        return AboutSettingsUiState(items = aboutSettingsItems())
    }

    override suspend fun handleIntent(intent: AboutSettingsIntent) {
        when (intent) {
            AboutSettingsIntent.Load -> loadSettings()
            is AboutSettingsIntent.OpenItem -> openItem(intent.id)
            is AboutSettingsIntent.ToggleTelemetry -> toggleTelemetry(intent.enabled)
            AboutSettingsIntent.ShowPrivacyDialog -> updateState { copy(showPrivacyDialog = true) }
            AboutSettingsIntent.DismissPrivacyDialog -> updateState { copy(showPrivacyDialog = false) }
            AboutSettingsIntent.OpenTelemetryDoc -> openTelemetryDoc()
        }
    }

    private suspend fun loadSettings() {
        val enabled = XRepo.telemetryEnabled()
        updateState { copy(telemetryEnabled = enabled) }
    }

    private suspend fun toggleTelemetry(enabled: Boolean) {
        updateState { copy(telemetryEnabled = enabled) }
        XRepo.setTelemetryEnabled(enabled)
    }

    private suspend fun openTelemetryDoc() {
        updateState { copy(showPrivacyDialog = false) }
        sendEffect(AboutSettingsEffect.OpenUri(TELEMETRY_DOC_URL))
    }

    private suspend fun openItem(id: AboutSettingsItemId) {
        val item = currentState.items.firstOrNull { it.id == id } ?: return
        when {
            item.uri != null -> sendEffect(AboutSettingsEffect.OpenUri(item.uri))
            item.bodyTemplateRes != null && item.feedbackTitle != null ->
                sendEffect(
                    AboutSettingsEffect.OpenFeedbackIssue(
                        item.feedbackTitle,
                        item.bodyTemplateRes,
                        XRepo.languageTag()
                    )
                )
        }
    }
}

private fun aboutSettingsItems(): List<AboutSettingsItemUiState> {
    return listOf(
        AboutSettingsItemUiState(
            id = AboutSettingsItemId.AuthorHomepage,
            titleRes = R.string.ui_settings_about_author_homepage,
            uri = "https://github.com/niki914",
        ),
        AboutSettingsItemUiState(
            id = AboutSettingsItemId.Github,
            titleRes = R.string.ui_settings_about_github,
            uri = "https://github.com/niki914/zafiro",
        ),
        AboutSettingsItemUiState(
            id = AboutSettingsItemId.Afdian,
            titleRes = R.string.ui_settings_about_afdian,
            uri = "https://afdian.com/a/niki914",
        ),
        AboutSettingsItemUiState(
            id = AboutSettingsItemId.Telegram,
            titleRes = R.string.ui_settings_about_telegram,
            uri = "https://t.me/+ZPX2xtSl6RwyZGNl",
        ),
        AboutSettingsItemUiState(
            id = AboutSettingsItemId.FeatureFeedback,
            titleRes = R.string.ui_settings_about_feedback_feature,
            uri = null,
            bodyTemplateRes = R.string.feedback_feature_template,
            feedbackTitle = FEATURE_FEEDBACK_TITLE,
        ),
        AboutSettingsItemUiState(
            id = AboutSettingsItemId.BugFeedback,
            titleRes = R.string.ui_settings_about_feedback_bug,
            uri = null,
            bodyTemplateRes = R.string.feedback_bug_template,
            feedbackTitle = BUG_FEEDBACK_TITLE,
        ),
    )
}

internal fun buildIssueUri(title: String, body: String): String {
    return Uri.Builder()
        .scheme("https")
        .authority("github.com")
        .path("/niki914/zafiro/issues/new")
        .appendQueryParameter("title", title)
        .appendQueryParameter("body", body)
        .build()
        .toString()
}

private const val FEATURE_FEEDBACK_TITLE = "[FEATURE] "
private const val BUG_FEEDBACK_TITLE = "[BUG] "
internal const val TELEMETRY_DOC_URL = "https://github.com/niki914/zafiro/blob/main/docs/TELEMETRY.md"
