package com.niki914.zafiro.app.ui.route

import androidx.compose.runtime.Composable
import com.niki914.zafiro.app.ui.home.HomePageContent
import com.niki914.zafiro.app.ui.nav.ConversationHistoryPage
import com.niki914.zafiro.app.ui.nav.SettingsHomePage
import com.niki914.zafiro.app.ui.nav.ZafiroPage

@Composable
internal fun HomePageRoute(
    isCurrentPage: Boolean = true,
    onPush: (ZafiroPage) -> Unit,
    onPushFromLeft: (ZafiroPage) -> Unit,
    selectedConversationId: String?,
    onConversationSelectionConsumed: (String) -> Unit,
    onActiveConversationChanged: (String?) -> Unit,
) {
    HomePageContent(
        isCurrentPage = isCurrentPage,
        selectedConversationId = selectedConversationId,
        onConversationSelectionConsumed = onConversationSelectionConsumed,
        onActiveConversationChanged = onActiveConversationChanged,
        onOpenHistory = {
            onPushFromLeft(ConversationHistoryPage)
        },
        onOpenSettings = {
            onPush(SettingsHomePage)
        },
    )
}
