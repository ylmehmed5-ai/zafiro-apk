package com.niki914.zafiro.app.ui.content

import android.content.Context
import android.content.res.Configuration
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.niki914.logging.Logger
import com.niki914.uikit.base.BaseTheme
import com.niki914.uikit.dialog.ZafiroDialog
import com.niki914.uikit.dialog.ZafiroDialogButton
import com.niki914.uikit.infra.component.settings.SettingsPageSpec
import com.niki914.uikit.infra.component.settings.SettingsRowAction
import com.niki914.uikit.infra.component.settings.SettingsRowLeadingIcon
import com.niki914.uikit.infra.component.settings.SettingsRowSpec
import com.niki914.uikit.infra.component.settings.SettingsSectionLayout
import com.niki914.uikit.infra.component.settings.SettingsSectionSpec
import com.niki914.uikit.infra.component.settings.SettingsSpecPageContent
import com.niki914.uikit.infra.nav.pageViewModel
import com.niki914.uikit.screen.ProvideZafiroScreenContentForPreview
import com.niki914.zafiro.app.BuildConfig
import com.niki914.zafiro.app.R
import com.niki914.zafiro.app.ui.model.AboutSettingsEffect
import com.niki914.zafiro.app.ui.model.AboutSettingsIntent
import com.niki914.zafiro.app.ui.model.AboutSettingsItemId
import com.niki914.zafiro.app.ui.model.AboutSettingsItemUiState
import com.niki914.zafiro.app.ui.model.AboutSettingsUiState
import com.niki914.zafiro.app.ui.model.AboutSettingsViewModel
import com.niki914.zafiro.app.ui.model.buildIssueUri

private const val ABOUT_SETTINGS_ROW_ID_PREFIX = "about.item."
private const val ABOUT_SETTINGS_TELEMETRY_ROW_ID = "about.item.telemetry"
private const val LOG_TAG = "niki914_zafiro_AboutSettings"

@Composable
fun AboutSettingsContent() {
    val viewModel = pageViewModel<AboutSettingsViewModel>()
    val uiState by viewModel.uiStateFlow.collectAsState()
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        viewModel.sendIntent(AboutSettingsIntent.Load)
    }

    LaunchedEffect(viewModel, uriHandler) {
        viewModel.uiEffect.collect { effect ->
            // 单个 effect 抛异常不能杀掉收集协程，否则后续 effect 全部无人接收（表现为点一次后再也点不动）
            runCatching {
                when (effect) {
                    is AboutSettingsEffect.OpenUri -> uriHandler.openUri(effect.uri)
                    is AboutSettingsEffect.OpenFeedbackIssue -> {
                        val body =
                            context.localizedString(effect.bodyTemplateRes, effect.languageTag)
                        uriHandler.openUri(buildIssueUri(effect.title, body))
                    }
                }
            }.onFailure { throwable ->
                Logger.w(LOG_TAG, "open effect failed: ${throwable.message}")
            }
        }
    }

    AboutSettingsContentBody(
        uiState = uiState,
        onItemClick = { itemId ->
            viewModel.sendIntent(AboutSettingsIntent.OpenItem(itemId))
        },
        onToggleTelemetry = { enabled ->
            viewModel.sendIntent(AboutSettingsIntent.ToggleTelemetry(enabled))
        },
        onShowPrivacyDialog = {
            viewModel.sendIntent(AboutSettingsIntent.ShowPrivacyDialog)
        },
        onPrivacyDialogDismiss = {
            viewModel.sendIntent(AboutSettingsIntent.DismissPrivacyDialog)
        },
        onPrivacyDialogViewDoc = {
            viewModel.sendIntent(AboutSettingsIntent.OpenTelemetryDoc)
        },
    )
}

@Composable
private fun AboutSettingsContentBody(
    uiState: AboutSettingsUiState,
    onItemClick: (AboutSettingsItemId) -> Unit,
    onToggleTelemetry: (Boolean) -> Unit = {},
    onShowPrivacyDialog: () -> Unit = {},
    onPrivacyDialogDismiss: () -> Unit = {},
    onPrivacyDialogViewDoc: () -> Unit = {},
) {
    if (uiState.showPrivacyDialog) {
        ZafiroDialog(
            visible = true,
            onDismissRequest = onPrivacyDialogDismiss,
            title = {
                Text(
                    text = stringResource(R.string.ui_settings_about_telemetry_dialog_title),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            content = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    Text(
                        text = stringResource(R.string.ui_settings_about_telemetry_dialog_text),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            actions = {
                ZafiroDialogButton(
                    text = stringResource(R.string.ui_settings_about_telemetry_dialog_negative),
                    onClick = onPrivacyDialogDismiss,
                    isPrimary = false,
                )
                ZafiroDialogButton(
                    text = stringResource(R.string.ui_settings_about_telemetry_dialog_positive),
                    onClick = onPrivacyDialogViewDoc,
                    isPrimary = true,
                )
            },
        )
    }

    SettingsSpecPageContent(
        spec = aboutSettingsSpec(
            uiState = uiState,
            versionName = BuildConfig.VERSION_NAME,
            description = stringResource(R.string.ui_settings_about_description),
        ),
        onAction = { action ->
            when (action) {
                is SettingsRowAction.Navigate -> {
                    if (action.id == ABOUT_SETTINGS_TELEMETRY_ROW_ID) {
                        onShowPrivacyDialog()
                        return@SettingsSpecPageContent
                    }
                    val itemId =
                        aboutSettingsItemIdFromRowId(action.id) ?: return@SettingsSpecPageContent
                    val item = uiState.items.firstOrNull { it.id == itemId }
                        ?: return@SettingsSpecPageContent
                    if (item.canOpen) {
                        onItemClick(itemId)
                    }
                }

                is SettingsRowAction.ToggleChanged -> {
                    if (action.id == ABOUT_SETTINGS_TELEMETRY_ROW_ID) {
                        onToggleTelemetry(action.checked)
                    }
                }

                else -> Unit
            }
        },
    )
}

@Composable
private fun aboutSettingsSpec(
    uiState: AboutSettingsUiState,
    versionName: String,
    description: String,
): SettingsPageSpec {
    val rows = uiState.items.map { item ->
        if (item.canOpen) {
            SettingsRowSpec.Navigation(
                id = aboutSettingsRowId(item.id),
                title = stringResource(item.titleRes),
                leadingIcon = item.leadingIcon(),
            )
        } else {
            SettingsRowSpec.Value(
                title = stringResource(item.titleRes),
                leadingIcon = item.leadingIcon(),
            )
        }
    } + listOf(
        SettingsRowSpec.ToggleNavigation(
            id = ABOUT_SETTINGS_TELEMETRY_ROW_ID,
            title = stringResource(R.string.ui_settings_about_telemetry_title),
            summary = stringResource(R.string.ui_settings_about_telemetry_summary),
            checked = uiState.telemetryEnabled,
            leadingIcon = SettingsRowLeadingIcon.Vector(Icons.Default.Analytics),
        ),
        SettingsRowSpec.Value(
            title = stringResource(R.string.ui_settings_about_version),
            currentState = versionName,
        ),
    )

    return SettingsPageSpec(
        description = description,
        sections = listOf(
            SettingsSectionSpec(
                layout = SettingsSectionLayout.GroupedCard,
                rows = rows,
            )
        ),
    )
}

// 用应用内语言设置解析字符串；空 tag 跟随系统默认解析
private fun Context.localizedString(@StringRes res: Int, tag: String): String {
    if (tag.isBlank()) return resources.getString(res)
    val config = Configuration(resources.configuration)
    config.setLocale(LocaleListCompat.forLanguageTags(tag).get(0))
    return createConfigurationContext(config).getString(res)
}

private fun aboutSettingsRowId(id: AboutSettingsItemId): String =
    "$ABOUT_SETTINGS_ROW_ID_PREFIX${id.name}"

private fun aboutSettingsItemIdFromRowId(id: String): AboutSettingsItemId? {
    if (!id.startsWith(ABOUT_SETTINGS_ROW_ID_PREFIX)) return null
    val rawId = id.removePrefix(ABOUT_SETTINGS_ROW_ID_PREFIX)
    return AboutSettingsItemId.entries.firstOrNull { it.name == rawId }
}

private fun AboutSettingsItemUiState.leadingIcon(): SettingsRowLeadingIcon {
    return when (id) {
        AboutSettingsItemId.AuthorHomepage,
        AboutSettingsItemId.Github -> SettingsRowLeadingIcon.PainterResource(R.drawable.github)

        AboutSettingsItemId.Afdian -> SettingsRowLeadingIcon.PainterResource(R.drawable.aifadian)
        AboutSettingsItemId.Telegram -> SettingsRowLeadingIcon.PainterResource(R.drawable.telegram)
        AboutSettingsItemId.FeatureFeedback -> SettingsRowLeadingIcon.Vector(Icons.Default.Feedback)
        AboutSettingsItemId.BugFeedback -> SettingsRowLeadingIcon.Vector(Icons.Default.BugReport)
    }
}

@Preview(name = "About Settings Light", showBackground = true, widthDp = 420, heightDp = 900)
@Composable
private fun AboutSettingsLightPreview() {
    BaseTheme(darkTheme = false, dynamicColor = false) {
        Surface {
            ProvideZafiroScreenContentForPreview(topPadding = 0.dp) {
                AboutSettingsContentBody(
                    uiState = previewAboutSettingsUiState(),
                    onItemClick = {},
                )
            }
        }
    }
}

@Preview(
    name = "About Settings Dark",
    showBackground = true,
    widthDp = 420,
    heightDp = 900,
    uiMode = Configuration.UI_MODE_NIGHT_YES,
)
@Composable
private fun AboutSettingsDarkPreview() {
    BaseTheme(darkTheme = true, dynamicColor = false) {
        Surface {
            ProvideZafiroScreenContentForPreview(topPadding = 0.dp) {
                AboutSettingsContentBody(
                    uiState = previewAboutSettingsUiState(),
                    onItemClick = {},
                )
            }
        }
    }
}

private fun previewAboutSettingsUiState(): AboutSettingsUiState {
    return AboutSettingsUiState(
        items = listOf(
            AboutSettingsItemUiState(
                id = AboutSettingsItemId.AuthorHomepage,
                titleRes = R.string.ui_settings_about_author_homepage,
                uri = "https://github.com/niki914",
            ),
            AboutSettingsItemUiState(
                id = AboutSettingsItemId.Github,
                titleRes = R.string.ui_settings_about_github,
                uri = "https://github.com/niki914/zafiro",
            ),
            AboutSettingsItemUiState(
                id = AboutSettingsItemId.Afdian,
                titleRes = R.string.ui_settings_about_afdian,
                uri = null,
            ),
            AboutSettingsItemUiState(
                id = AboutSettingsItemId.Telegram,
                titleRes = R.string.ui_settings_about_telegram,
                uri = null,
            ),
            AboutSettingsItemUiState(
                id = AboutSettingsItemId.FeatureFeedback,
                titleRes = R.string.ui_settings_about_feedback_feature,
                uri = "https://github.com/niki914/zafiro/issues/new",
            ),
            AboutSettingsItemUiState(
                id = AboutSettingsItemId.BugFeedback,
                titleRes = R.string.ui_settings_about_feedback_bug,
                uri = "https://github.com/niki914/zafiro/issues/new",
            ),
        )
    )
}
